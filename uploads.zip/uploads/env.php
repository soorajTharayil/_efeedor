<?php
$config_set = array(
    "DBHOST"=>"localhost",
    "BASE_URL"=>"https://natusmr.efeedor.com/",
    "DOMAIN"=>"natusmr.efeedor.com",
    "DBUSER"=>"efeedor_core",
    "DBPASSWORD"=>"Vishnu99%",
    "DBNAME"=>"efeedor_acc_natusmr_bangalore"
)
?>
