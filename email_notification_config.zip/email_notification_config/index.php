<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$all_pending_email = file_get_contents('https://feedback.meitra.com/pendingemail.php');
$all_email_array = json_decode($all_pending_email, false);

if (count($all_email_array) > 0) {
	foreach ($all_email_array as $row) {
		$EMAIL_CONTENT = $row;
		date_default_timezone_set('Etc/UTC');

		require 'PHPMailer/PHPMailerAutoload.php';
		$mail = new PHPMailer;
		$mail->isSMTP();
		$mail->SMTPDebug = 4;
		$mail->Debugoutput = 'html';
		$mail->Host = "mail.meitra.com";
		$mail->Port = 587;
		$mail->SMTPAuth = true;
		$mail->SMTPSecure = 'tls';
		$mail->Username = "feedback@meitra.com";
		$mail->Password = 'Feed$Back@Meitra!';
		$mail->setFrom('feedback@meitra.com', 'Patients Feedback');
		$mail->addReplyTo('feedback@meitra.com', 'Patients Feedback');
		$mail->AltBody = $EMAIL_CONTENT->message;
		$mail->Subject = $EMAIL_CONTENT->subject;
		$mail->SMTPOptions = array(
			'ssl' => array(
				'verify_peer' => false,
				'verify_peer_name' => false,
				'allow_self_signed' => true
			)
		);
		//print_r($mail); exit;
		$messages = $EMAIL_CONTENT->message;
		$mail->ClearAddresses();
		$mail->addAddress($EMAIL_CONTENT->mobile_email, $EMAIL_CONTENT->mobile_email);
		$mail->msgHTML($messages);
		if (!$mail->send()) {
			echo "Mailer Error: " . $mail->ErrorInfo;
		} else {
			echo "Message sent!";
		}
	}
}

?>